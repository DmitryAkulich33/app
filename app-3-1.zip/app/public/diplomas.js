const state = { excel: null, template: null };
const $ = (id) => document.getElementById(id);
const KINDS = { template: 'diploma-template', excel: 'diploma-excel' };
let running = false;

function row(entry, onRemove) {
  const div = document.createElement('div');
  const cls = entry.status === 'pending' ? 'pending' : entry.status === 'ok' ? 'ok' : 'bad';
  div.className = `vrow ${cls}`;
  div.innerHTML = '<span class="dot"></span><div><div class="file"></div><div class="msg"></div></div><button title="Remove">×</button>';
  div.querySelector('.dot').textContent = entry.status === 'pending' ? '…' : entry.status === 'ok' ? '✓' : '✕';
  div.querySelector('.file').textContent = entry.file.name;
  div.querySelector('.msg').textContent = entry.status === 'pending' ? 'Validating…' : entry.message;
  div.querySelector('button').onclick = onRemove;
  return div;
}

function render() {
  for (const kind of ['template', 'excel']) {
    const box = $(`v-${kind}`);
    box.replaceChildren();
    if (!state[kind]) box.innerHTML = '<div class="empty">No file attached.</div>';
    else box.append(row(state[kind], () => { state[kind] = null; render(); }));
  }
  const ready = state.template?.status === 'ok' && state.excel?.status === 'ok';
  $('run').disabled = !ready || running;
  $('run-hint').textContent = ready ? 'All files are valid. You can generate the diplomas.' : 'Attach valid files in sections 1–2 to enable the button.';
}

async function validate(kind, entry) {
  const fd = new FormData();
  fd.append('file', entry.file);
  try {
    const r = await (await fetch(`/api/validate/${KINDS[kind]}`, { method: 'POST', body: fd })).json();
    entry.status = r.valid ? 'ok' : 'bad';
    entry.message = r.message;
  } catch (e) {
    entry.status = 'bad';
    entry.message = 'Validation failed: the server is not reachable.';
  }
  render();
}

function add(kind, files) {
  if (!files.length) return;
  const entry = { file: files[0], status: 'pending' };
  state[kind] = entry;
  validate(kind, entry);
  render();
}

for (const kind of ['template', 'excel']) {
  const input = $(`in-${kind}`);
  const zone = document.querySelector(`[data-drop="${kind}"]`);
  input.addEventListener('change', () => { add(kind, [...input.files]); input.value = ''; });
  zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('over'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('over'));
  zone.addEventListener('drop', (e) => { e.preventDefault(); zone.classList.remove('over'); add(kind, [...e.dataTransfer.files]); });
}

$('run').addEventListener('click', async () => {
  running = true;
  render();
  $('spinner').classList.remove('hidden');
  $('log').innerHTML = '<div class="empty">Генерация дипломов…</div>';
  $('downloads').innerHTML = '<div class="empty">The generated Word file will appear here.</div>';
  $('individual').innerHTML = '<div class="empty">The individual Word files will appear here.</div>';

  const fd = new FormData();
  fd.append('excel', state.excel.file);
  fd.append('template', state.template.file);
  try {
    const res = await fetch('/api/generate-diplomas', { method: 'POST', body: fd });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Server error');
    $('log').replaceChildren(...data.log.map((l) => {
      const d = document.createElement('div');
      d.className = l.type;
      d.textContent = l.text;
      return d;
    }));
    const box = $('downloads');
    box.replaceChildren();
    if (!data.file) box.innerHTML = '<div class="empty">No Word file was generated.</div>';
    else {
      const a = document.createElement('a');
      a.className = 'btn secondary';
      a.href = `/api/download/${data.file.id}`;
      a.textContent = `Download: ${data.file.name}`;
      box.append(a);
    }
    const ibox = $('individual');
    if (data.individual) {
      ibox.replaceChildren();
      const all = document.createElement('a');
      all.className = 'btn';
      all.href = `/api/download/${data.individual.zip.id}`;
      all.textContent = `Download all (${data.individual.files.length}) as ZIP`;
      ibox.append(all);
    } else ibox.innerHTML = '<div class="empty">No individual files were generated.</div>';
  } catch (e) {
    const d = document.createElement('div');
    d.className = 'error';
    d.textContent = `Ошибка при создании дипломов: ${e.message}`;
    $('log').replaceChildren(d);
  } finally {
    running = false;
    $('spinner').classList.add('hidden');
    render();
  }
});

render();
