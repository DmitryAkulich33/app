const $ = (id) => document.getElementById(id);

// key = form field name; kind = validator on the server
const SLOTS = [
  { key: 'templateCommon', kind: 'supp-template-common', title: 'Common diploma supplement', accept: '.docx', multiple: false },
  { key: 'templateHonors', kind: 'supp-template-honors', title: 'Diploma supplement for a degree with honors', accept: '.docx', multiple: false },
  { key: 'diplomas', kind: 'supp-diploma', accept: '.docx', multiple: true },
  { key: 'numbers', kind: 'supp-numbers', accept: '.xls,.xlsx', multiple: false },
  { key: 'marks', kind: 'supp-marks', accept: '.doc,.docx', multiple: true },
  { key: 'defense', kind: 'supp-defense', accept: '.doc,.docx', multiple: true },
  { key: 'electives', kind: 'supp-electives', accept: '.xls,.xlsx', multiple: false },
  { key: 'prev', kind: 'supp-prev', accept: '.doc,.docx', multiple: true },
];
const state = Object.fromEntries(SLOTS.map((s) => [s.key, []]));
let running = false;

for (const s of SLOTS) {
  const root = $(`slot-${s.key}`);
  root.innerHTML = `${s.title ? `<h3>${s.title}</h3>` : ''}
    <label class="dropzone">Click or drop ${s.multiple ? 'the files' : 'the file'} here
      <input type="file" accept="${s.accept}" ${s.multiple ? 'multiple' : ''} hidden>
    </label>
    <div class="validation"><h3>Validation</h3><div class="vbox"></div></div>`;
  const input = root.querySelector('input');
  const zone = root.querySelector('.dropzone');
  input.addEventListener('change', () => { add(s, [...input.files]); input.value = ''; });
  zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('over'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('over'));
  zone.addEventListener('drop', (e) => { e.preventDefault(); zone.classList.remove('over'); add(s, [...e.dataTransfer.files]); });
}

function row(entry, onRemove) {
  const div = document.createElement('div');
  div.className = `vrow ${entry.status === 'pending' ? 'pending' : entry.status === 'ok' ? 'ok' : 'bad'}`;
  div.innerHTML = '<span class="dot"></span><div><div class="file"></div><div class="msg"></div></div><button title="Remove">×</button>';
  div.querySelector('.dot').textContent = entry.status === 'pending' ? '…' : entry.status === 'ok' ? '✓' : '✕';
  div.querySelector('.file').textContent = entry.file.name;
  div.querySelector('.msg').textContent = entry.status === 'pending' ? 'Validating…' : entry.message;
  div.querySelector('button').onclick = onRemove;
  return div;
}

const allValid = (keys) => {
  const all = keys.flatMap((k) => state[k]);
  return all.length > 0 && all.every((e) => e.status === 'ok');
};

// Section 1 needs at least one template (either one); every other section needs at least one file. Nothing may be invalid.
const ready = () => allValid(['templateCommon', 'templateHonors']) && ['diplomas', 'numbers', 'marks', 'defense', 'electives', 'prev'].every((k) => allValid([k]));

function render() {
  for (const s of SLOTS) {
    const box = $(`slot-${s.key}`).querySelector('.vbox');
    box.replaceChildren();
    if (!state[s.key].length) box.innerHTML = '<div class="empty">No file attached.</div>';
    for (const entry of state[s.key]) {
      box.append(row(entry, () => { state[s.key] = state[s.key].filter((e) => e !== entry); render(); }));
    }
  }
  const ok = ready();
  $('run').disabled = !ok || running;
  $('run-hint').textContent = ok
    ? 'All files are valid. You can generate the diploma supplements.'
    : 'Attach valid files in sections 1–7 to enable the button (section 1: at least one template).';
}

async function validate(s, entry) {
  const fd = new FormData();
  fd.append('file', entry.file);
  try {
    const r = await (await fetch(`/api/validate/${s.kind}`, { method: 'POST', body: fd })).json();
    entry.status = r.valid ? 'ok' : 'bad';
    entry.message = r.message;
  } catch (e) {
    entry.status = 'bad';
    entry.message = 'Validation failed: the server is not reachable.';
  }
  render();
}

function add(s, files) {
  if (!files.length) return;
  const picked = s.multiple ? files : [files[0]];
  if (!s.multiple) state[s.key] = [];
  for (const file of picked) {
    const entry = { file, status: 'pending' };
    state[s.key].push(entry);
    validate(s, entry);
  }
  render();
}

$('run').addEventListener('click', async () => {
  running = true;
  render();
  $('spinner').classList.remove('hidden');
  $('log').innerHTML = '<div class="empty">Генерация приложений к дипломам…</div>';
  $('downloads').innerHTML = '<div class="empty">The ZIP file will appear here.</div>';
  const fd = new FormData();
  for (const s of SLOTS) for (const e of state[s.key]) fd.append(s.key, e.file);
  try {
    const res = await fetch('/api/generate-supplements', { method: 'POST', body: fd });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Server error');
    $('log').replaceChildren(...data.log.map((l) => {
      const d = document.createElement('div');
      d.className = l.type;
      d.textContent = l.text;
      return d;
    }));
    const box = $('downloads');
    box.replaceChildren();
    if (!data.zip) box.innerHTML = '<div class="empty">No diploma supplement was generated.</div>';
    else {
      const a = document.createElement('a');
      a.className = 'btn';
      a.href = `/api/download/${data.zip.id}`;
      a.textContent = `Download: ${data.zip.name}`;
      box.append(a);
    }
  } catch (e) {
    const d = document.createElement('div');
    d.className = 'error';
    d.textContent = `Ошибка при создании приложений: ${e.message}`;
    $('log').replaceChildren(d);
  } finally {
    running = false;
    $('spinner').classList.add('hidden');
    render();
  }
});

render();
