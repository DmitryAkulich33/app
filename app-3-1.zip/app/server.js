const path = require('path');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');
const { validateEmail } = require('./lib/msg');
const { readStudents } = require('./lib/excel');
const { validateTemplate } = require('./lib/template');
const { generateCertificates } = require('./lib/generator');
const { readDiplomaStudents, validateDiplomaTemplate, generateDiplomas } = require('./lib/diplomas');
const S = require('./lib/supplements');

const PORT = 5555;
const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 200 * 1024 * 1024 } });

// multer decodes file names as latin1; restore UTF-8 (Russian / Chinese names).
const fileName = (f) => Buffer.from(f.originalname, 'latin1').toString('utf8');

const results = new Map();
const TTL = 60 * 60 * 1000;

app.use(express.static(path.join(__dirname, 'public')));

const WORD = { ext: /\.docx?$/i, extMessage: 'Only Word files (.doc, .docx) are accepted.' };
const DOCX = { ext: /\.docx$/i, extMessage: 'Only Word files (.docx) are accepted.' };
const XLS = { ext: /\.xlsx?$/i, extMessage: 'Only Excel files (.xls, .xlsx) are accepted.' };

const validators = {
  'supp-template-common': { ...DOCX, run: (buf) => S.validateSupplementTemplate(buf, 'common') },
  'supp-template-honors': { ...DOCX, run: (buf) => S.validateSupplementTemplate(buf, 'honors') },
  'supp-diploma': { ...DOCX, run: (buf, name) => S.validateSupplementDiploma(buf, name) },
  'supp-numbers': { ...XLS, run: (buf) => S.validateNumbers(buf) },
  'supp-marks': { ...WORD, run: (buf, name) => S.validateMarks(buf, name) },
  'supp-defense': { ...WORD, run: (buf, name) => S.validateDefense(buf, name) },
  'supp-electives': { ...XLS, run: (buf) => S.validateElectives(buf) },
  'supp-prev': { ...WORD, run: (buf, name) => S.validatePrev(buf, name) },
  'diploma-template': {
    ext: /.docx$/i,
    extMessage: 'Only Word files (.docx) are accepted.',
    run: (buf) => {
      validateDiplomaTemplate(buf);
      return 'Valid diploma template: student names, registration numbers and gendered verbs were found.';
    },
  },
  'diploma-excel': {
    ext: /.xlsx?$/i,
    extMessage: 'Only Excel files (.xls, .xlsx) are accepted.',
    run: (buf) => {
      const { students, problems } = readDiplomaStudents(buf);
      const note = problems ? ` ${problems} row(s) have missing or invalid data; no diploma will be created for them.` : '';
      return `Valid Excel file: ${students.length} student(s) found.${note}`;
    },
  },
  email: {
    ext: /\.(msg|eml|emlx)$/i,
    extMessage: 'Only email files (.msg, .eml, .emlx) are accepted.',
    run: validateEmail,
  },
  excel: {
    ext: /\.xlsx?$/i,
    extMessage: 'Only Excel files (.xls, .xlsx) are accepted.',
    run: (buf) => `Valid Excel file: ${readStudents(buf).length} master students found on the "магистранты" sheet.`,
  },
  template: {
    ext: /\.docx$/i,
    extMessage: 'Only Word files (.docx) are accepted.',
    run: (buf) => {
      validateTemplate(buf);
      return 'Valid certificate template: all fields to fill were found.';
    },
  },
};

app.post('/api/validate/:kind', upload.single('file'), async (req, res) => {
  const v = validators[req.params.kind];
  if (!v || !req.file) return res.status(400).json({ valid: false, message: 'No file was received.' });
  const name = fileName(req.file);
  if (!v.ext.test(name)) return res.json({ valid: false, message: v.extMessage });
  try {
    res.json({ valid: true, message: await v.run(req.file.buffer, name) });
  } catch (e) {
    res.json({ valid: false, message: e.message });
  }
});

app.post('/api/generate', upload.fields([{ name: 'emails' }, { name: 'excel', maxCount: 1 }, { name: 'template', maxCount: 1 }]), async (req, res) => {
  const f = req.files || {};
  if (!f.emails || !f.excel || !f.template) return res.status(400).json({ error: 'Attach the emails, the Excel file and the template first.' });
  try {
    const { log, files, excelOut } = await generateCertificates({
      emails: f.emails.map((e) => ({ name: fileName(e), buffer: e.buffer })),
      excel: f.excel[0].buffer,
      template: f.template[0].buffer,
    });
    const out = files.map((file) => {
      const id = crypto.randomUUID();
      results.set(id, { name: file.name, buffer: file.buffer });
      setTimeout(() => results.delete(id), TTL).unref();
      return { id, name: file.name, count: file.count };
    });
    let excelFile = null;
    if (excelOut) {
      const id = crypto.randomUUID();
      const name = fileName(f.excel[0]).replace(/\.xlsx?$/i, '') + '.xlsx';
      results.set(id, { name, buffer: excelOut, type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      setTimeout(() => results.delete(id), TTL).unref();
      excelFile = { id, name };
    }
    res.json({ log, files: out, excelFile });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/generate-diplomas', upload.fields([{ name: 'excel', maxCount: 1 }, { name: 'template', maxCount: 1 }]), (req, res) => {
  const f = req.files || {};
  if (!f.excel || !f.template) return res.status(400).json({ error: 'Attach the diploma template and the Excel file first.' });
  try {
    const { log, file, individual } = generateDiplomas({
      excel: f.excel[0].buffer,
      template: f.template[0].buffer,
      templateName: fileName(f.template[0]),
    });
    let out = null;
    if (file) {
      const id = crypto.randomUUID();
      results.set(id, { name: file.name, buffer: file.buffer });
      setTimeout(() => results.delete(id), TTL).unref();
      out = { id, name: file.name, count: file.count };
    }
    const store = (name, buffer, type) => {
      const id = crypto.randomUUID();
      results.set(id, { name, buffer, type });
      setTimeout(() => results.delete(id), TTL).unref();
      return id;
    };
    const single = individual && {
      files: individual.files.map((f) => ({ id: store(f.name, f.buffer), name: f.name })),
      zip: { id: store(individual.zipName, individual.zip, 'application/zip'), name: individual.zipName },
    };
    res.json({ log, file: out, individual: single });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

const SUPP_FIELDS = [
  { name: 'templateCommon', maxCount: 1 }, { name: 'templateHonors', maxCount: 1 }, { name: 'diplomas' },
  { name: 'numbers', maxCount: 1 }, { name: 'marks' }, { name: 'defense' }, { name: 'electives', maxCount: 1 }, { name: 'prev' },
];

app.post('/api/generate-supplements', upload.fields(SUPP_FIELDS), (req, res) => {
  const f = req.files || {};
  if ((!f.templateCommon && !f.templateHonors) || !f.diplomas || !f.numbers || !f.marks || !f.defense || !f.electives || !f.prev) {
    return res.status(400).json({ error: 'Attach the files in sections 1-7 first.' });
  }
  const list = (arr) => arr.map((x) => ({ name: fileName(x), buffer: x.buffer }));
  try {
    const { log, zip } = S.generateSupplements({
      templates: { common: f.templateCommon && f.templateCommon[0].buffer, honors: f.templateHonors && f.templateHonors[0].buffer },
      diplomas: list(f.diplomas),
      numbers: f.numbers[0].buffer,
      marks: list(f.marks),
      defense: list(f.defense),
      electives: f.electives[0].buffer,
      prev: list(f.prev),
    });
    let out = null;
    if (zip) {
      const id = crypto.randomUUID();
      results.set(id, { name: zip.name, buffer: zip.buffer, type: 'application/zip' });
      setTimeout(() => results.delete(id), TTL).unref();
      out = { id, name: zip.name };
    }
    res.json({ log, zip: out });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/download/:id', (req, res) => {
  const r = results.get(req.params.id);
  if (!r) return res.status(404).send('File not found or expired.');
  res.setHeader('Content-Type', r.type || 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
  res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(r.name)}`);
  res.send(r.buffer);
});

app.listen(PORT, () => console.log(`International Relations Department tools: http://localhost:${PORT}`));
