# Department of International Relations tools

    npm install
    npm start        # http://localhost:5555

Feature 1 - certificates of diploma confirmation: attach .msg / .eml / .emlx emails (diploma scans as PDF), the Excel file
(sheet "магистранты") and the Word template, then press "Generate certificates".
Diploma scans are read with OCR (Tesseract, Russian model in `tessdata/`, works offline).
Template: the sample certificate wording, or placeholders {имя} {диплом} {рег номер} {протокол}.

Feature 2 - diplomas (`/diplomas.html`): attach a Word diploma template and an Excel file (columns "имя русск", "имя англ",
"пол" м/ж, "рег номер"), then press "Generate diplomas". One Word file is produced with a diploma per student (own page):
Russian and English names and registration numbers are replaced, and the verbs "поступил(а)" / "завершил(а)" follow the gender.
Template spots are found by wording: the line after "Настоящий диплом свидетельствует о том, что" / "This diploma is issued to certify that",
"Регистрационный № …" / "Registration № …". Students with missing or invalid data are skipped and listed in the result (Russian).
