const state = { email: [], excel: null, template: null };
const $ = (id) => document.getElementById(id);

function row(entry, onRemove) {
  const div = document.createElement('div');
  const cls = entry.status === 'pending' ? 'pending' : entry.status === 'ok' ? 'ok' : 'bad';
  div.className = `vrow ${cls}`;
  const mark = entry.status === 'pending' ? '…' : entry.status === 'ok' ? '✓' : '✕';
  div.innerHTML = '<span class="dot"></span><div><div class="file"></div><div class="msg"></div></div><button title="Remove">×</button>';
  div.querySelector('.dot').textContent = mark;
  div.querySelector('.file').textContent = entry.file.name;
  div.querySelector('.msg').textContent = entry.status === 'pending' ? 'Validating…' : entry.message;
  div.querySelector('button').onclick = onRemove;
  return div;
}

function render() {
  const emailBox = $('v-email');
  emailBox.replaceChildren();
  if (!state.email.length) emailBox.innerHTML = '<div class="empty">No emails attached.</div>';
  state.email.forEach((e) => emailBox.append(row(e, () => { state.email = state.email.filter((x) => x !== e); render(); })));
  for (const kind of ['excel', 'template']) {
    const box = $(`v-${kind}`);
    box.replaceChildren();
    if (!state[kind]) box.innerHTML = '<div class="empty">No file attached.</div>';
    else box.append(row(state[kind], () => { state[kind] = null; render(); }));
  }
  const ready = state.email.length > 0 && state.email.every((e) => e.status === 'ok')
    && state.excel?.status === 'ok' && state.template?.status === 'ok';
  $('run').disabled = !ready || running;
  $('run-hint').textContent = ready ? 'All files are valid. You can generate the certificates.' : 'Attach valid files in sections 1–3 to enable the button.';
}

async function validate(kind, entry) {
  const fd = new FormData();
  fd.append('file', entry.file);
  try {
    const r = await (await fetch(`/api/validate/${kind}`, { method: 'POST', body: fd })).json();
    entry.status = r.valid ? 'ok' : 'bad';
    entry.message = r.message;
  } catch (e) {
    entry.status = 'bad';
    entry.message = 'Validation failed: the server is not reachable.';
  }
  render();
}

function add(kind, files) {
  if (!files.length) return;
  if (kind === 'email') {
    for (const file of files) {
      if (state.email.some((e) => e.file.name === file.name && e.file.size === file.size)) continue;
      const entry = { file, status: 'pending' };
      state.email.push(entry);
      validate('email', entry);
    }
  } else {
    state[kind] = { file: files[0], status: 'pending' };
    validate(kind, state[kind]);
  }
  render();
}

for (const kind of ['email', 'excel', 'template']) {
  const input = $(`in-${kind}`);
  const zone = document.querySelector(`[data-drop="${kind}"]`);
  input.addEventListener('change', () => { add(kind, [...input.files]); input.value = ''; });
  zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('over'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('over'));
  zone.addEventListener('drop', (e) => { e.preventDefault(); zone.classList.remove('over'); add(kind, [...e.dataTransfer.files]); });
}

let running = false;

$('run').addEventListener('click', async () => {
  running = true;
  render();
  $('spinner').classList.remove('hidden');
  $('log').innerHTML = '<div class="empty">Генерация…</div>';
  $('downloads').innerHTML = '<div class="empty">Generated Word files will appear here.</div>';

  const fd = new FormData();
  state.email.forEach((e) => fd.append('emails', e.file));
  fd.append('excel', state.excel.file);
  fd.append('template', state.template.file);
  try {
    const res = await fetch('/api/generate', { method: 'POST', body: fd });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Server error');
    $('log').replaceChildren(...data.log.map((l) => {
      const d = document.createElement('div');
      d.className = l.type;
      d.textContent = l.text;
      return d;
    }));
    const box = $('downloads');
    box.replaceChildren();
    if (!data.files.length) box.innerHTML = '<div class="empty">No Word files were generated.</div>';
    for (const f of data.files) {
      const a = document.createElement('a');
      a.className = 'btn secondary';
      a.href = `/api/download/${f.id}`;
      a.textContent = `Download: ${f.name}`;
      box.append(a);
    }
  } catch (e) {
    $('log').innerHTML = '';
    const d = document.createElement('div');
    d.className = 'error';
    d.textContent = `Ошибка при создании справок: ${e.message}`;
    $('log').append(d);
  } finally {
    running = false;
    $('spinner').classList.add('hidden');
    render();
  }
});

render();
