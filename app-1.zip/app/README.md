# Department of International Relations tools

    npm install
    npm start        # http://localhost:5555

Feature 1 - certificates of diploma confirmation: attach .msg / .eml / .emlx emails (diploma scans as PDF), the Excel file
(sheet "магистранты") and the Word template, then press "Generate certificates".
Diploma scans are read with OCR (Tesseract, Russian model in `tessdata/`, works offline).
Template: the sample certificate wording, or placeholders {имя} {диплом} {рег номер} {протокол}.
